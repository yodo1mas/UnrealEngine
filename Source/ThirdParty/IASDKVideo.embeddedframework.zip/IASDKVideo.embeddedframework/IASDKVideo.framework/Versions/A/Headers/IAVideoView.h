//
//  IAVideoView.h
//  IASDKVideo
//
//  Created by Fyber on 02/07/2017.
//  Copyright © 2017 Fyber. All rights reserved.
//

#import <IASDKCore/IAMRAIDAdView.h>

@interface IAVideoView : IAMRAIDAdView

@end

//
//  IAMediationIronSource.h
//  IASDKCore
//
//  Created by Fyber on 9/26/19.
//  Copyright © 2019 Fyber. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IASDKCore/IAMediation.h>

@interface IAMediationIronSource : IAMediation

@end

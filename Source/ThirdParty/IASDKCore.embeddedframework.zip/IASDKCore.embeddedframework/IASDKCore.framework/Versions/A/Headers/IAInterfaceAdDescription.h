//
//  IAInterfaceAdDescription.h
//  IASDKCore
//
//  Created by Fyber on 27/04/2017.
//  Copyright © 2017 Fyber. All rights reserved.
//

#ifndef IAInterfaceAdDescription_h
#define IAInterfaceAdDescription_h

#import <Foundation/Foundation.h>

@protocol IAInterfaceAdDescription <NSObject>

@required

@end

#endif /* IAInterfaceAdDescription_h */

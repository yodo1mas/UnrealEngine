//
//  IAContentController.h
//  IASDKCore
//
//  Created by Fyber on 19/03/2017.
//  Copyright © 2017 Fyber. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  @brief  Abstract base class.
 */
@interface IAContentController : NSObject

@end

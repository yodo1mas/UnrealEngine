//
//  IARequest.h
//  IASDKCore
//
//  Created by Fyber on 13/03/2017.
//  Copyright © 2017 Fyber. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IARequest : NSObject

@end

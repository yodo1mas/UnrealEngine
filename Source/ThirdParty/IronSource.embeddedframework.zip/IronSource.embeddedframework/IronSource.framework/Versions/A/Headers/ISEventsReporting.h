//
//  Copyright © 2017 IronSource. All rights reserved.
//

#ifndef ISEventsReporting_h
#define ISEventsReporting_h

#import <Foundation/Foundation.h>

@interface ISEventsReporting : NSObject

+(void) reportAppStarted DEPRECATED_MSG_ATTRIBUTE("");

@end

#endif


